import React, { PureComponent } from 'react';
import { StyleSheet, Text, TouchableOpacity, View , ImageBackground, Image, Dimensions, Platform} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import { RNCamera, FaceDetector } from 'react-native-camera';
import img from "./res/Main.png"
import logo from "./res/Logo.png"
import logo1 from"./res/Logo1.png"
import {RFValue} from "react-native-responsive-fontsize"
import {create} from "apisauce"
import {getMacAddress} from 'react-native-device-info';
import axios  from 'axios'
const H = Dimensions.get("screen").height
const W = Dimensions.get("screen").width
const URL = "URL"
export interface Iimage {
  image: any []
  i  : number, 
  username:string,
  patientid:string,
  counter : number,
  datapath:string,
  fileName:String,
  loading:boolean,
  nameDevice:string, 
}
class Detail  extends React.Component <Iimage > {
    constructor(props:Iimage) {
      super(props)
      this.state = {
        image: [],
        i: 0,
        username:'',
        patientid:'string' ,
        counter : 1,
        datapath:"",
        fileName:"",
        loading:"",
        answer :"N",
        nameDevice:"",
        macDevice:""


      }
    }
  _storeDataTrue = async () => {
      try {
        await AsyncStorage.setItem('KEY_CHANGE','true');
      } catch (error) {
        console.log(error)
      }
    };
    _storeDataFalse = async () => {
      try {
        await AsyncStorage.setItem('KEY_CHANGE','false');
      } catch (error) {
        console.log(error)
      }
    };



  componentDidMount = () =>{
  //this.takeMotherFuker()  
  }

  componentDidUpdate = () => {
    if(this.state.counter === 0){ 
      clearInterval(this.interval);
     }
  
    }
  _device = () =>
  {
    getMacAddress().then (mac => {
     this.setState({macDevcice:mac})
     console.log(this.state.macDevice) 
     this._convertDevice(mac)
    })
  }
  _convertDevice = (param) => 
  {
    switch(param) {
 
      case '18:93:7F:B3:CE:A6':
        this.setState({nameDevice:"1"});
        break;
      
      case '18:93:7F:B4:4C:E0':
        this.setState({nameDevice:"2"});
        break;
 
      case '18:93:7F:B3:FC:6A':
        this.setState({nameDevice:"3"});
        break;
 
      case '18:93:7F:B3:BF:AC':
        this.setState({nameDevice:"4"});
        break;
      case '18:93:7F:B4:A4:24':
          this.setState({nameDevice:"5"});
          break;
      default:
       console.log("MAC NOT FOUND");
    
      }
  }
  componentWillUnmount=() => {
    clearInterval(this.interval);
   }
  onHandelBack = () => 
  {
   this.props.navigation.navigate("AnotherDetail")
   this._storeDataFalse()
  }
  onHandeNext = () => {
    this.props.navigation.navigate("AnotherDetail")
    this._storeDataTrue()
   // this._Yes()
  } 
  private _Yes = () => {
    console.log('upload comfirm')
    const data = new FormData();
    // const re = new FormData();  
    // data.append('File', file)
    data.append('Result', '{"ans_1":"Y","ans_2":"N"}');
    console.log(data)
    // re.append('Result', {
    //   value : result

    // })
    // console.log(data)

    var params = {
      patient_code: '079048.200044015',
      request_date: '2020-02-02'
    }

    const url = "http://14.241.239.78:8091/uat.tek.btc.survey/api/Survery/result";
    let options = {
      method: 'POST',
      headers: {
        'content-type': 'multipart/form-data',
      },
      body: data
    };
    axios({
      method: 'post',
      url: url,
      data: data,
      headers: { 'content-type': 'multipart/form-data' }
    })
      .then(function (response) {
        //handle success
        console.log(response);
      })
      .catch(function (response) {
        //handle error
        console.log(response);
      });
   
    };

    private _No = () => {
      console.log('upload comfirm')
      const data = new FormData();
      // const re = new FormData();  
      // data.append('File', file)
      data.append('Result', '{"ans_1":"N","ans_2":"Y"}');
      console.log(data)
      // re.append('Result', {
      //   value : result
  
      // })
      // console.log(data)
  
      var params = {
        patient_code: '079048.200044015',
        request_date: '2020-02-02'
      }
  
      const url = "http://14.241.239.78:8091/uat.tek.btc.survey/api/Survery/result";
      let options = {
        method: 'POST',
        headers: {
          'content-type': 'multipart/form-data',
        },
        body: data
      };
      axios({
        method: 'post',
        url: url,
        data: data,
        headers: { 'content-type': 'multipart/form-data' }
      })
        .then(function (response) {
          //handle success
          console.log(response);
        })
        .catch(function (response) {
          //handle error
          console.log(response);
        });
     
      };
  private _uploadImage = ( file : any) => {
    console.log('upload comfirm')
    const data = new FormData();
    // const re = new FormData();  
    // data.append('File', file)
    data.append('Result', '{"ans_1":"Y","ans_2":"N"}');
    console.log(data)
    // re.append('Result', {
    //   value : result

    // })
    // console.log(data)

    var params = {
      patient_code: '079048.200044015',
      request_date: '2020-02-02'
    }

    const url = "http://14.241.239.78:8091/uat.tek.btc.survey/api/Survery/result";
    let options = {
      method: 'POST',
      headers: {
        'content-type': 'multipart/form-data',
      },
      body: data
    };
    axios({
      method: 'post',
      url: url,
      data: data,
      headers: { 'content-type': 'multipart/form-data' }
    })
      .then(function (response) {
        //handle success
        console.log(response);
      })
      .catch(function (response) {
        //handle error
        console.log(response);
      });
   
    };
  render() {

    return (
      <View style={styles.container}>
        <RNCamera
          ref={(ref) => {
            this.camera = ref;
          }}
          style={styles.preview}
          type={RNCamera.Constants.Type.back}
          flashMode={RNCamera.Constants.FlashMode.on}
          androidCameraPermissionOptions={{
            title: 'Permission to use camera',
            message: 'We need your permission to use your camera',
            buttonPositive: 'Ok',
            buttonNegative: 'Cancel',
          }}
          androidRecordAudioPermissionOptions={{
            title: 'Permission to use audio recording',
            message: 'We need your permission to use your audio',
            buttonPositive: 'Ok',
            buttonNegative: 'Cancel',
          }}
          
        />
      <ImageBackground style={styles.Bg} 
                        source ={img}      

      > 
      <View style={styles.subContainer}>
      <View style = {{justifyContent:"flex-start",marginHorizontal:40, marginVertical:50, alignItems:"center"}}>
        <View style = {{flexDirection:"row",alignItems:"center", marginHorizontal:10, marginVertical:20}}>
          <Image source={logo} style={styles.image}/>
          <Image source={logo1} style={styles.image}/>
        </View>
        <View style={{ flex:1 ,boderWidth: 1 ,boderBottomColor:"red", marginBottom:150, }}>
        <Text style={styles.TitleTitle}>
           HỆ THỐNG KHAI BÁO Y TẾ TỰ ĐỘNG
         </Text>
        </View>
      </View>
        <View style={styles.subsubContainer}>
         
            <Text style ={styles.title}> YẾU TỐ DỊCH TỄ : </Text>
            <View style={{marginLeft:70}}>
            <Text style={styles.textStyle}>Có một trong những yếu tố, trong vòng 14 ngày:</Text>
            <Text style={styles.textStyle}>  - Là người từ nước ngoài vào Việt Nam</Text>
            <Text style={styles.textStyle}>  - Tiếp xúc người nước ngoài vào Việt Nam (người này đến </Text>
            <Text style={styles.textStyle}>    Việt Nam trong vòng 14 ngày)</Text>
            <Text style={styles.textStyle}>  - Tiếp xúc với người nghi nhiễm COVID-19 </Text>
            <Text></Text>
           

        </View>
        <View style={{ flex: 0, flexDirection: 'row', justifyContent: 'center', marginTop:50, marginHorizontal:100, }}>
          <TouchableOpacity onPress={this.onHandelBack} style={styles.capture}>
            <Text style={[styles.textStyle,{color:"#fff", fontSize:40,fontWeight:"bold",marginVertical:10, marginHorizontal :20}]}>KHÔNG</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={ this.onHandeNext} style={styles.capture1}>
            <Text style={[styles.textStyle,{color:"#fff", fontSize:40,fontWeight:"bold",marginVertical:10 , marginHorizontal:20}]}>CÓ</Text>
          </TouchableOpacity>
        </View>
        </View>
        </View>
        </ImageBackground>
      </View>
    );
  }
  takeMotherFuker = () => {
 
    this.interval = setInterval(this.takePicture.bind(this),2000)
  }
  takePicture = async () => {
    console.log("camera was click")
      const options = { quality: 0, base64: true ,fixOrientation: true,};
      const data = await this.camera.takePictureAsync(options);

     //console.log(data.base64);
      console.log(data.uri);
      this._uploadImage(data);
      this.setState({i : this.state.i+1})
      this.setState( {counter : this.state.counter-1})
  
  };
}
export default (Detail)
const styles = StyleSheet.create({
image:{
  width: 300,
  height: 200,
  resizeMode: 'stretch',
},
preview: {
    flex: 0,
    justifyContent:"center",
    height:1,
    width:1 
},
container: {
  flex: 1,
  justifyContent:"flex-start"
},
subContainer:{
  flex:1,
  justifyContent:"flex-start",
  marginHorizontal:20
},
capture: {
  flex: 1,
  backgroundColor: "#000",
  borderRadius: 10,
  paddingHorizontal: RFValue(10,H),
  margin: 10,
  alignItems:"center", 
  marginVertical: 10
},
capture1: {
  flex: 1,
  backgroundColor: "red",
  borderRadius: 10,
  paddingHorizontal: RFValue(10,H),
  margin: 10,
  marginVertical:10, 
  alignItems:"center",

},
TitleTitle:{
  textAlign :"center" , 
   marginVertical:10, 
   fontSize:RFValue(40,H), 
   color:"#C2000B",
   marginTop:60,
   fontWeight:"bold",
   padding:20, 
   borderBottomColor: '#707070',
   borderBottomWidth: 2
},
subsubContainer:{
  textAlign :"center" ,
   marginVertical:10, 
   fontSize:RFValue(50,H), 
   color:"red",             
   marginTop:60,
   fontWeight:"bold"
  },

title:{
  fontSize:RFValue(40,H),
  color:"#000",
  textAlign:"left",
  marginBottom:15,
  fontWeight:"bold",
  marginHorizontal:30
},
textStyle:{
  color : "#000",
  fontSize:RFValue(35,H),                               
  marginVertical:10,
  paddingVertical:5
  
},
Bg : {
  resizeMode:"cover",
  justifyContent: "flex-start",
  flex:1
},
});