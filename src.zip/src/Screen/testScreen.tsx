import * as React from 'react'
import { getUniqueId, getManufacturer, getDeviceName ,getIpAddress , getDeviceId, getDevice,getMacAddress} from 'react-native-device-info';
import {Text, View} from "react-native"
export default class TestScreen extends React.Component
{
    
    constructor(props){
        super(props)
       this.state ={
           nameDevice:"",
           macDevice:""
       }
    }
public componentDidMount = () => 
{
    this._Android()
}
private _Android = () => {
    getDeviceName().then(deviceName => {console.log(deviceName)})
    getIpAddress().then(ip => {console.log(ip)})
    console.log(getDeviceId())
    getDevice().then(device => {console.log(device)})
    getMacAddress().then(mac => {

        this._convertDevice(mac)
      });

}
_convertDevice = (param) => 
{ 
    console.log("chay")
    console.log(param)
    switch(param) {
 
        case '9C:5C:F9:CA:DC:4F':
          this.setState({nameDevice:"1"});
          console.log(1)
          break;
         default:
            console.log("MAC NOT FOUND");

}
}
//   switch(param) {

//     case '18:93:7F:B3:CE:A6':
//       this.setState({nameDevice:"1"});
//       console.log(this.state.nameDevice)
//       break;
    
//     case '9C:5C:F9:CA:DC:4F':
//       this.setState({nameDevice:"2"});
//       console.log(this.state.nameDevice)
//       break;

//     case '3':
//       this.setState({nameDevice:"3"});
//       break;

//     case '4':
//       this.setState({nameDevice:"4"});
//       break;
//     case '4':
//         this.setState({nameDevice:"5"});
//         break;
//     default:
//      console.log("MAC NOT FOUND");
  
    

render()
{
    return(
    
    <View>
        <Text>{this.state.nameDevice}</Text>
     </View>
    )
}
}