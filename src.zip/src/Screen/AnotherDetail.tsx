import React, { PureComponent } from 'react';
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Alert,
  ImageBackground,
  Image, Dimensions,
} from 'react-native';
import { RNCamera, FaceDetector } from 'react-native-camera';
import AsyncStorage from '@react-native-community/async-storage';
import { RFPercentage, RFValue } from "react-native-responsive-fontsize";
import EStyleSheet from 'react-native-extended-stylesheet';
import { getMacAddress } from 'react-native-device-info';
import img from "./res/Main.png"
import logo from "./res/Logo.png"
import logo1 from "./res/Logo1.png"
import { create } from "apisauce"
import axios from 'axios'
const H = Dimensions.get("screen").height
const W = Dimensions.get("screen").width
// ADD URL 

export interface Iimage {
  image: any[]
  i: number,
  username: string,
  patientid: string,
  isSick: boolean,
  notSick: string,
  isChange: string,
  nameDevice: string,
  count: 5
  //counter : number
}
class AnotherDetail extends React.Component<Iimage> {
  constructor(props: Iimage) {
    super(props)
    this.state = {
      image: [],
      isChange: "",
      notSick: "N",
      nameDevice: "",
      count: 5,
      i: 0

    }
  }
  componentDidMount = () => {
    this._retrieveData()
    this.takeMotherFuker()
    this._device()
  }
  componentDidUpdate = () => {
    if (this.state.counter === 0) {
      clearInterval(this.interval);
    }

  }
  _retrieveData = async () => {
    try {
      const value = await AsyncStorage.getItem('KEY_CHANGE');
      if (value !== null) {
        this.setState({
          isChange: value
        })
        console.log(value);
      }
    } catch (error) {
      // Error retrieving data
    }
  };

  onHandelBack = () => {
    this.props.navigation.navigate("Home")
  }
  _alert = () => {
    Alert.alert("Thông báo", "Hoàn thành khai báo")
    this._No()
    this.onHandelBack()
  }
  _Ugotsickmotherfucker = () => {
    this.takePicture.bind(this)
    this.props.navigation.navigate("UGotSick")
    this.setState({
      isSick: "Y"
    })

  }

  _device = () => {
    getMacAddress().then(mac => {
      this.setState({ macDevcice: mac })
      console.log(this.state.macDevice)
      this._convertDevice(mac)
    })
  }
  _convertDevice = (param) => {
    switch (param) {

      case '18:93:7F:B3:CE:A6':
        this.setState({ nameDevice: "kiosk1" });
        break;

      case '18:93:7F:B4:4C:E0':
        this.setState({ nameDevice: "kiosk2" });
        break;

      case '18:93:7F:B3:FC:6A':
        this.setState({ nameDevice: "kiosk3" });
        break;

      case '18:93:7F:B3:BF:AC':
        this.setState({ nameDevice: "kiosk4" });
        break;
      case '18:93:7F:B4:A4:24':
        this.setState({ nameDevice: "kiosk5" });
        break;
      default:
        console.log("MAC NOT FOUND");

    }
  }
  _checkSick = () => {
    (this.state.isChange === 'true') ? (this.takePicture.bind(this), this.props.navigation.navigate("UGotSick")) : this._alert()
  }


  private _Yes = (file) => {
    console.log('upload comfirm')
    const data = new FormData();
    // const re = new FormData();  
    // data.append('File', file)
    data.append('Files[0]', file.base64);
    data.append('Files[1]', file.base64);
    data.append('Files[2]', file.base64);
    data.append('Files[3]', file.base64);
    data.append('Files[4]', file.base64);
    data.append('Result', '{"ans_1":"' + this.state.notSick + '","ans_2":"Y"}');
    data.append('User', this.state.nameDevice);
    console.log(data)
    // re.append('Result', {
    //   value : result

    // })
    // console.log(data)

    var params = {
      patient_code: '079048.200044015',
      request_date: '2020-02-02'
    }

    const url = "http://14.241.239.78:8091/uat.tek.btc.survey/api/Survery/result";
    let options = {
      method: 'POST',
      headers: {
        'content-type': 'multipart/form-data',
      },
      body: data
    };
    axios({
      method: 'post',
      url: url,
      data: data,
      headers: { 'content-type': 'multipart/form-data' }
    })
      .then(function (response) {
        //handle success
        console.log(response);
      })
      .catch(function (response) {
        //handle error
        console.log(response);
      });

  };

  private _No = () => {
    console.log('upload comfirm')
    const data = new FormData();
    // const re = new FormData();  
    // data.append('File', file)
    data.append('Result', '{"ans_1":"N","ans_2":"N"}');
    console.log(data)
    // re.append('Result', {
    //   value : result

    // })
    // console.log(data)

    var params = {
      patient_code: '079048.200044015',
      request_date: '2020-02-02'
    }

    const url = "http://14.241.239.78:8091/uat.tek.btc.survey/api/Survery/result";
    let options = {
      method: 'POST',
      headers: {
        'content-type': 'multipart/form-data',
      },
      body: data
    };
    axios({
      method: 'post',
      url: url,
      data: data,
      headers: { 'content-type': 'multipart/form-data' }
    })
      .then(function (response) {
        //handle success
        console.log(response);
      })
      .catch(function (response) {
        //handle error
        console.log(response);
      });

  };
  render() {
    return (
      <View style={styles.container}>
        <RNCamera
          ref={(ref) => {
            this.camera = ref;
          }}
          style={styles.preview}
          type={RNCamera.Constants.Type.back}
          flashMode={RNCamera.Constants.FlashMode.on}
          androidCameraPermissionOptions={{
            title: 'Permission to use camera',
            message: 'We need your permission to use your camera',
            buttonPositive: 'Ok',
            buttonNegative: 'Cancel',
          }}
          androidRecordAudioPermissionOptions={{
            title: 'Permission to use audio recording',
            message: 'We need your permission to use your audio',
            buttonPositive: 'Ok',
            buttonNegative: 'Cancel',
          }}

        />
        <ImageBackground style={styles.Bg}
          source={img}
        >
          <View style={styles.subContainer}>
            <View style={{ justifyContent: "center", marginHorizontal: 30, marginVertical: 50, alignItems: "center" }}>
              <View style={{ flexDirection: "row", alignItems: "center", marginHorizontal: 50, alignContent: "center" }}>
                <Image source={logo} style={styles.image} />
                <Image source={logo1} style={styles.image} />
              </View>
              <Text style={styles.TitleTitle}>
                HỆ THỐNG KHAI BÁO Y TẾ TỰ ĐỘNG
         </Text>
            </View>
            <View>
              <View style={styles.subsubContainer}>
                <Text style={styles.title}> YẾU TỐ LÂM SÀNG : </Text>
                <View style={{ marginHorizontal: 80 }}>
                  <Text style={styles.textStyle}>  - Có một trong những triệu chứng </Text>
                  <Text style={styles.textStyle}>     Sốt, ho, sổ mũi, đau họng, khó thở, viêm phổi </Text>
                  <Text></Text>
                  <Text></Text>
                  <Text></Text>
                  <Text></Text>
                  <Text></Text>
                  <Text></Text>


                  <View style={{ flex: 0, flexDirection: 'row', justifyContent: 'center', marginTop: 100 }}>
                    <TouchableOpacity onPress={() => this._checkSick()} style={styles.capture}>
                      <Text style={[styles.textStyle, { color: "#fff", fontSize: 40, fontWeight: "bold", marginVertical: 10, marginHorizontal: 20 }]}>KHÔNG</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.capture1} onPress={() => this._Ugotsickmotherfucker()} >
                      <Text style={[styles.textStyle, { color: "#fff", fontSize: 40, fontWeight: "bold", marginVertical: 10, marginHorizontal: 20 }]}>CÓ</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            </View>
          </View>

        </ImageBackground>
      </View>
    );
  }
  takeMotherFuker = () => {

    // this.interval = setInterval(this.takePicture.bind(this),2000)
  }
  takePicture = async () => {
    console.log("camera was click")
    const options = { quality: 0, base64: true, fixOrientation: true, };
    const data = await this.camera.takePictureAsync(options);
    await this._Yes(data);
    //console.log(data.base64);
    console.log(data.uri);
    this.setState({ i: this.state.i + 1 })
    this.setState({ counter: this.state.counter - 1 })

  };
}
export default (AnotherDetail)
const styles = StyleSheet.create({
  image: {
    width: 300,
    height: 200,
    resizeMode: 'stretch',
  },
  preview: {
    flex: 0,
    justifyContent: "center",
    height: 1,
    width: 1
  },
  container: {
    flex: 1,
    justifyContent: "flex-start"
  },
  subContainer: {
    flex: 1,
    justifyContent: "flex-start",
    marginHorizontal: 20
  },
  capture: {
    flex: 1,
    backgroundColor: "#000",
    borderRadius: 10,
    paddingHorizontal: RFValue(10, H),
    margin: 10,
    alignItems: "center",
    marginVertical: 10
  },
  capture1: {
    flex: 1,
    backgroundColor: "red",
    borderRadius: 10,
    paddingHorizontal: RFValue(10, H),
    margin: 10,
    marginVertical: 10,
    alignItems: "center",

  },
  TitleTitle: {
    textAlign: "center",
    marginVertical: 10,
    fontSize: RFValue(40, H),
    color: "#C2000B",
    marginTop: 60,
    fontWeight: "bold",
    padding: 20,
    borderBottomColor: '#707070',
    borderBottomWidth: 2
  },
  subsubContainer: {
    textAlign: "center",
    marginVertical: 10,
    fontSize: RFValue(50, H),
    color: "red",
    marginTop: 60,
    fontWeight: "bold",
    marginHorizontal: 20,
  },

  title: {
    fontSize: RFValue(50, H),
    color: "#000",
    textAlign: "left",
    marginBottom: 15,
    fontWeight: "bold",
    marginHorizontal: 30
  },
  textStyle: {
    color: "#000",
    fontSize: RFValue(35, H),
    marginVertical: 20,
    paddingVertical: 5

  },
  Bg: {
    resizeMode: "cover",
    justifyContent: "flex-start",
    flex: 1
  },
});