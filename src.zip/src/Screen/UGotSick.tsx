
import * as React from "react"
import {View , Text , Button, TouchableOpacity, StyleSheet, ImageBackground,Dimensions , Image, } from "react-native"
import BG from "./res/Main.png"
import LOGO from "./res/Logo.png"
import {RFValue} from "react-native-responsive-fontsize"
interface iUserImage {
    username:string
}
const H = Dimensions.get("screen").height
const W = Dimensions.get("screen").width
 
export default class UGotSick extends React.Component {

constructor (props) {
    super(props)
    this.state = {
        username:""
     }
}
    changeDetail = () =>
    {
        this.props.navigation.navigate("Home")
    }
    handleUserName =(text)=>
    {
        this.setState({
            username: text
        })
    }
    render() {
        return (
            <View style={styles.container}>
            <ImageBackground style = {styles.Bg}
            source = {BG}
            > 
            <View style={styles.subContainer}>
            <Image source={LOGO} style={styles.image} />
            <View></View>
              <Text style={styles.TitleTitle}>HỆ THỐNG KHAI BÁO Y TẾ TỰ ĐỘNG </Text>

              <Text style={styles.textStyle}>MỜI BẠN ĐỨNG YÊN TẠI CHỖ  </Text>
              <View></View>
            <TouchableOpacity style={styles.capture1} onPress={()=>this.changeDetail()}>
            <Text style={[styles.title,{color:"#fff"}]}>KẾT THÚC</Text>
            <View></View>
            </TouchableOpacity>
            </View>
            </ImageBackground>
            </View>
        )
    }
}
const styles = StyleSheet.create({
  image:{
    width: 300,
    height: 200,
    resizeMode: 'stretch',
  },
  preview: {
      flex: 0,
      justifyContent:"center",
      height:1,
      width:1 
  },
  container: {
    flex: 1,
    justifyContent:"flex-start",
  },
  subContainer:{
    flex:1,
    justifyContent:"center",
    marginHorizontal:"10%",
    alignItems:"center",
    paddingVertical:10,
    marginVertical:50
  },
  capture: {
    flex: 1,
    backgroundColor: "#000",
    borderRadius: 10,
    paddingHorizontal: RFValue(20,H),
    paddingVertical:RFValue(20,H),
    margin: 15,
    alignItems:"center"
  
  },
  capture1: {
    flex: 0,
    backgroundColor: "red",
    borderRadius: 10,
    paddingHorizontal: RFValue(150,H),
    margin: 50,
    alignItems:"center",
    paddingVertical:RFValue(5,H),
  
  },
  TitleTitle:{
    textAlign :"center", 
    marginVertical:70,
    fontSize:RFValue(40,H), 
    color:"#C2000B",
    fontWeight:"bold",
    padding:20, 
    borderBottomColor: '#707070',
    borderBottomWidth: 2  
  },
  title:{
    fontSize:RFValue(40,H),
    color:"#000",
    textAlign:"left",
    marginBottom:10,
    marginVertical:40,
    fontWeight:"bold",
    marginTop:10
  },
  textStyle:{
    color : "#000",
    fontSize:RFValue(35,H),
    marginBottom:70
  },
  Bg : {
    resizeMode:"cover",
    justifyContent: "flex-start",
    flex:1
  },
  });